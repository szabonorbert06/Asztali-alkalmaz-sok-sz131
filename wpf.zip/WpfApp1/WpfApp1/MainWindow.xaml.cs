﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<ToDo> _items = new();
        private readonly ICollectionView _view;

        public MainWindow()
        {
            InitializeComponent();

            _view = CollectionViewSource.GetDefaultView(_items);
            _view.Filter = FilterTodos;
            LB.ItemsSource = _view;

            TB_Search.TextChanged += TB_Search_TextChanged;
            TB_Editor.KeyDown += TB_Editor_KeyDown;
        }

        private bool FilterTodos(object obj)
        {
            var q = (TB_Search.Text ?? string.Empty).Trim();
            return obj is ToDo todo && (string.IsNullOrEmpty(q) ||
                todo.Description?.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void TB_Search_TextChanged(object sender, TextChangedEventArgs e) => _view.Refresh();

        private void TB_Search_Clear_Click(object sender, RoutedEventArgs e)
        {
            TB_Search.Clear();
            _view.Refresh();
            LB.SelectedItem = null;
        }

        private void BTN_Save_Click(object sender, RoutedEventArgs e) => AddItem();

        private void AddItem()
        {
            var text = (TB_Editor.Text ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Írj be egy leírást.", "Figyelem", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var item = new ToDo
            {
                Description = text,
                IsCompleted = CB_IsCompleted.IsChecked ?? false,
                IsSelected = false
            };

            _items.Add(item);
            _view.Refresh();
            LB.SelectedItem = item;
            ResetEditor();
        }

        private void TB_Editor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                AddItem();
                e.Handled = true;
            }
        }

        private void BTN_Edit_Click(object sender, RoutedEventArgs e)
        {
            if (LB.SelectedItem is not ToDo selected)
            {
                MessageBox.Show("Válassz ki egy elemet a szerkesztéshez.", "Figyelem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var newText = (TB_Editor.Text ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(newText))
            {
                MessageBox.Show("A leírás nem lehet üres.", "Figyelem", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            selected.Description = newText;
            selected.IsCompleted = CB_IsCompleted.IsChecked ?? false;

            
            var idx = _items.IndexOf(selected);
            if (idx >= 0) _items[idx] = selected;

            _view.Refresh();
            LB.SelectedItem = selected;
            ResetEditor();
        }

        private void BTN_Delete_Click(object sender, RoutedEventArgs e)
        {
            var toRemove = _items.Where(x => x.IsSelected).ToList();
            if (toRemove.Count == 0 && LB.SelectedItem is ToDo single) toRemove.Add(single);
            if (toRemove.Count == 0) return;

            var names = string.Join(", ", toRemove.Select(x => x.Description));
            var res = MessageBox.Show($"Törölni szeretnéd: {names}?", "Megerősítés", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (res != MessageBoxResult.Yes) return;

            foreach (var r in toRemove) _items.Remove(r);

            _view.Refresh();
            ResetEditor();
        }

        private void LB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = LB.SelectedItem as ToDo;
            TB_Editor.Text = selected?.Description ?? string.Empty;
            CB_IsCompleted.IsChecked = selected?.IsCompleted ?? false;
        }

        
        private void ResetEditor()
        {
            TB_Editor.Clear();
            CB_IsCompleted.IsChecked = false;
        }
    }
}