﻿using System;

namespace WpfApp1
{
    public class ToDo
    {
        public string Description { get; set; } = string.Empty;
        public bool IsCompleted { get; set; } = false;
        public bool IsSelected { get; set; } = false; // checkbox for multi-delete
        public DateTime Created { get; set; } = DateTime.Now;

        public override string ToString() => Description ?? string.Empty;
    }
}
